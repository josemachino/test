<?php
interface ConfigurationRest
{
    public function saveWPConfiguration(WP_REST_Request $request);
    public function getWPConfiguration();
}
class WP_Config_Controller implements ConfigurationRest{

    public function __construct(){
        $this->namespace = 'api-chazki/v1';
        $this->resource = 'config';        
        add_action('rest_api_init', array($this, 'register_routes'));        
    }
    
    public function register_routes(){
        register_rest_route( $this->namespace, '/' . $this->resource, array(
            'methods'   => WP_REST_Server::READABLE,
            'permission_callback' => '__return_true',
            'callback'  => array($this, 'getWPConfiguration')
        ));
        register_rest_route( $this->namespace, '/' . $this->resource, array(
            'methods'             => 'POST',
            'permission_callback' => '__return_true', // *always set a permission callback
            'callback'            => array($this, 'saveWPConfiguration')
        ));
    }

    /**
    * rest_enterpriseKey_endpoint
    * @return WP_REST_Response
    */
   public function getWPConfiguration()
   {
       global $wpdb;
       $results = $wpdb->get_results( "SELECT HEX(enterprisekey) as enterprisekey FROM {$wpdb->prefix}chazki limit 1", OBJECT );
       $response = "";
       if ($results) {
           $array = get_object_vars($results[0]);
           $value = strtolower(substr($array['enterprisekey'],0,8))."-".strtolower(substr($array['enterprisekey'],8,4))."-".strtolower(substr($array['enterprisekey'],12,4))."-".strtolower(substr($array['enterprisekey'],16,4))."-".strtolower(substr($array['enterprisekey'],20));
           $response = array(
               'status'  => 200,
               'message' => $value
           );
       }else {
           $response = array(
               'status'  => 400,
               'message' => '0'
           );
       }
       
       
       return new WP_REST_Response($response);
   }
   
   
   /**
    * rest_saveEK_endpoint
    * @return WP_REST_Response
    */
   public function saveWPConfiguration(WP_REST_Request $request){
       global $wpdb;
       $body = $request->get_json_params();
       $user = get_user_by( 'email', $body['email-admin'] );                 
       // Insert in tonny credentials    
       $postRequest = $wpdb->get_results("SELECT consumer_key, consumer_secret FROM {$wpdb->prefix}woocommerce_api_keys WHERE user_id = ". $user->ID ." and permissions = 'read_write' limit 1 ;");       
       if ( !empty( $postRequest ) ) {
            $postRequest = $postRequest[0];
            $query = "DELETE FROM wp_chazki where enterprisekey = UNHEX(REPLACE('".$body['enterprise-key']."', '-',''));";
            $wpdb->query($query);
            $query = "INSERT INTO wp_chazki(enterprisekey) VALUES (UNHEX(REPLACE('".$body['enterprise-key']."', '-','')));";
            $wpdb->query($query);
            $response = array(
                'status' => 200,
                'message' => 'Enterprise-key updated'
            );       
                    
            $postRequest->{"enterprisekey"} = $body['enterprise-key'];
            $postRequest->{'branchCode'} = $body['branchCode'];       
            $postRequest->{'idPlatform'} = $_SERVER['SERVER_NAME'];
            $postRequest->{'token'} = '';
            $postRequest->{'namePlatform'} = 'WOOCOMMERCE';

            $data = wp_remote_post("https://webhook.site/cf81cbdc-99d5-4737-82f7-4448964df62c", array(
                'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
                'body'        => json_encode((array)$postRequest),
                'method'      => 'POST',
                'data_format' => 'body',
                ));
       } else {
            $response = array(
                'status' => 400,
                'message' => 'REST API must be enabled'
            );  
       }
                        
       return new WP_REST_Response($response);
   }
   
}
?>