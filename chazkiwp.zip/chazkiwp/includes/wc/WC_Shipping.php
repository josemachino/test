<?php

class WC_Shipping_Constructor {
    public function __construct($typeMethod){
        $txt =
        "<?php

        include_once( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php');

        class WC_Chazki_". $typeMethod ."_Shipping extends WC_Shipping_Method {
            /**
             * Constructor for your shipping class
             *
             * @access public
             * @return void
             */
            public function __construct() {
                \$this->id                 = '". strtolower($typeMethod) . "_chazki'; // Id for your shipping method. Should be unique.        
                \$this->method_title       = __( 'Chazki ". $typeMethod . "', '". strtolower($typeMethod) ."_chazki');  // Title shown in admin
                \$this->method_description = __( 'Description of your shipping method', '". strtolower($typeMethod) ."_chazki' ); // Description shown in admin                
                \$this->supports           = array(
                    'shipping-zones',            
                    'instance-settings',
                    'instance-settings-modal',
                );
                \$this->init();
            }



            public function init() {
                // Load the settings API
                \$this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings
                \$this->init_settings(); // This is part of the settings API. Loads settings you previously init.

                // Define user set variables.
                \$this->title    = isset(\$this->settings['title']) ? \$this->settings['title'] : __( 'Chazki ". $typeMethod ." Ship', '". strtolower($typeMethod) ."_chazki');
                // Save settings in admin if you have any defined
                add_action( 'woocommerce_update_options_shipping_' . \$this->id, array( \$this, 'process_admin_options' ) );
            }

            /**
            * Define settings field for this shipping
            * @return void
            */

            public function init_form_fields() {    
                \$this->form_fields = array(
                    'enabled' => array(        
                        'title' => __( 'Enable', \$this->id ),            
                        'type' => 'checkbox',            
                        'description' => __( 'Enable this shipping.', \$this->id ),            
                        'default' => 'yes'            
                    ),                        
                    'title' => array(            
                        'title' => __( 'Title', \$this->id ),            
                        'type' => 'text',            
                        'description' => __( 'Title to be display on site', \$this->id ),            
                        'default' => \$this->method_title             
                    ),
                    'cost' => array(            
                        'title' => __( 'Cost', \$this->id ),            
                        'type' => 'text',            
                        'description' => __( 'Cost to display', \$this->id ),            
                        'default' => __( 0, \$this->id )            
                    ),                        
                );
                    
            }

            /**
             * calculate_shipping function.
             *
             * @access public
             * @param mixed \$package
             * @return void
             */
            public function calculate_shipping( \$package = array() ) {
                \$rate = array(
                    'id' => \$this->id,
                    'label' => \$this->title,
                    'cost' => 0,
                    'calc_tax' => 'per_item'
                );

                // Register the rate
                \$this->add_rate( \$rate );
            }

            public function getId(){
                return \$this->id;
            }

            public static function woocommerce_shipping_methods( \$methods ) {		
                \$methods['".strtolower($typeMethod)."_chazki']= 'WC_Chazki_". $typeMethod ."_Shipping'; 		
                return \$methods;
            }
        }

?>";
        $this->nameShipping = $typeMethod;
        $this->data=stripslashes($txt);
    }

    public function createFile(){        
        $myfile = fopen( dirname( __FILE__) . "/WC_Chazki_". $this->nameShipping ."_Shipping.php", "w") or die("Unable to open file!");
        fwrite($myfile, $this->data);
        fclose($myfile);
    } 
}




