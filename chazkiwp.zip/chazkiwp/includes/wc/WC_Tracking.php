<?php

class WC_TrackingMetaBox {
    public function __construct(){
        $this->id = "chazki_order_meta_box";
        $this->title = "Chazki";
        
        $this->init();
    }

    function init(){
        add_action( 'add_meta_boxes', array( $this, 'addMetaBoxChazkiInfo') );        
    }
    public function addMetaBoxChazkiInfo(){
        add_meta_box(
            $this->id, // $id
            __($this->title, 'woocommerce'), // $title 
            array($this, 'chazki_custom_meta_box'), // $callback
            'shop_order', // $page
            'side', // $context
            'core'); // $priority
    }

    public function chazki_custom_meta_box( $order ){
        //global $post;
        //check if order has shipping method with chazki
        $order = wc_get_order( $order->ID );
        $methods = ['Chazki Express','Chazki Regular'];
        
        if (in_array($order->get_shipping_method(), $methods)) {
            $meta_field_data = get_post_meta( $order->ID, '_my_field_slug', true ) ? get_post_meta( $order->ID, '_my_field_slug', true ) : '';            
            //$body = array( $_SERVER['SERVER_NAME'] ,$order->ID);
            $body = array( 'integracionzeldacl.myshopify.com' ,'666');
            $url = CHAZKI_INTEGRATION_HOST . 'getLinksOrder' ;
            $infoTonny = wp_remote_get( $url, array(
                'headers'     => array('Accept' => 'application/json'),
                'body'        => $body
                ));
            echo $infoTonny;
            /*echo '
            <label htmlFor="trackCode" >
                    Codigo de Seguimiento
                <span onClick="location.href = '. $infoTonny->routeTracking .' " id="trackCode" class = "label label-info"> '. $infoTonny->trackCode .' </span>
            </label> 
            <span onClick="location.href = '. $infoTonny->urlPdf .'" >Descargar etiqueta</span>
            ';*/
        } else {
            echo '<p>Esta orden no tiene envio con Chazki</p>';
        }
        
    }

}
?>