<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Chazki
 * @subpackage Chazki/admin
 * @author     Catolico 
 */

class Chazki_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	private $_configController;
	
	public $_shippingControllerExpress;
	public $_shippingControllerRegular;
	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		add_action( 'admin_menu', array($this, 'chazkiMenu'));
		require_once DIR_PATH . 'includes/controllers/WP_Config_Controller.php';
		require_once DIR_PATH . 'includes/wc/WC_Tracking.php';
		$this->services = ['Express', 'Regular'];
		$this->_configController = new WP_Config_Controller();		
		$this->_trackingMetabox = new WC_TrackingMetaBox();		
	}

	public function shipping_method (){
		require_once DIR_PATH . 'includes/wc/WC_Shipping.php';		
		for ($i=0; $i < count($this->services); $i++){ 
			if (!class_exists('WC_Chazki_'. $this->services[$i] .'_Shipping')) {
				$this->_shippingConstructor = new WC_Shipping_Constructor($this->services[$i]);
				$this->_shippingConstructor->createFile();
				require_once DIR_PATH . 'includes/wc/WC_Chazki_'. $this->services[$i] .'_Shipping.php';
			}			
			// add_action( 'woocommerce_shipping_init', );	
			// $this->currentService = $this->services[$i];
			add_filter( 'woocommerce_shipping_methods', array("WC_Chazki_". $this->services[$i] ."_Shipping", 'woocommerce_shipping_methods'));
		}		
	}

	

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style( 'chazki-style', plugin_dir_url( dirname( __FILE__ ) ) . 'build/index.css' , array(), date("h:i:s") );
    	wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' );
		//wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/plugin-name-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		//In a subdirectory within plugin directory is used plugin_dir_url( dirname( __FILE__ ) )
		wp_enqueue_script( 'chazki-script', plugin_dir_url( dirname( __FILE__ ) ) .'build/index.js', array( 'wp-element','wp-api-fetch' ), date("h:i:s"), true );
	}
	

	/**
	 * Init admin Menu
	 */
	public function chazkiMenu(){
		add_menu_page( 
			__('Chazki','Chazki'), 
			__('Chazki','Chazki Configuration'),
			'manage_options',
			'chazki',
			array( $this , 'chazkiAdminPage'),
			plugin_dir_url( dirname( __FILE__ ) ) . 'assets/chazki-icon.png'
		);
	}

	

	public function chazkiAdminPage() {
		echo "<div id='chazki'> Chazki </div>";
		$this->install();    
	}
	private function install(){    
		global $wpdb;    
		$plugin_name_db_version = '1.0.0';
		$charset_collate = $wpdb->get_charset_collate();
		$sql="
		DROP TABLE IF EXISTS `" .$wpdb->prefix."chazki`;";
		$wpdb->query($sql);    
		$wpdb->show_errors();
		$sql="
		DROP TABLE IF EXISTS `" .$wpdb->prefix."chazki`;
		CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."chazki`
		(
			enterprisekey BINARY(16) PRIMARY KEY
		);";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta($sql);

		add_option( 'plugin_name_db_version', $plugin_name_db_version );
	}	

}

?>