import './index.css';
import App from './App';
import { render } from '@wordpress/element';

render(<App />, document.getElementById('chazki'));
