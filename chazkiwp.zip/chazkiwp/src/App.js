import React from 'react';
import Dashboard from './components/Dashboard';
import TabContent from './components/TabContent';

const App = () => {
    return (
        <div>
            <h2 className='app-title'>Chazki Configuration</h2>
            <hr />
            
            <TabContent>
                <div label="Configuracion">
                <Dashboard />
                </div>
                <div label="Envios">
                After 'while, <em>Crocodile</em>!
                </div>
            </TabContent>
        </div>
  );
}

export default App;
