import React, { useState } from 'react'
import apiFetch from '@wordpress/api-fetch';

const Dashboard = () => {
    const [enterpriseKey,setEnterpriseKey ]= useState('')
    const [branchCode,setBranchCode]= useState('')
    const [emailAdmin,setEmailAdmin]= useState('')
    const handleSubmit = async (e) => {
    
        e.preventDefault();

        console.log(`Form submitted, ${enterpriseKey}`);    
        // GET
        await apiFetch( {
            path: 'api-chazki/v1/config',
            method: 'POST',
            data: { 
                "enterprise-key": enterpriseKey,
                "branchCode": branchCode,
                "email-admin": emailAdmin
        },
        } ).then( ( res ) => {
            console.log( res );
        });
    }
    return (
        <div className='dashboard'>
            <form onSubmit={handleSubmit}>
            <div className='form-outline mb-4'>
                <label htmlFor='enterpriseKey' className='form-label'>
                    Api-key
                    <input id="enterpriseKey" onChange = {(e) => setEnterpriseKey(e.target.value)} value={enterpriseKey} placeholder="Enterprise-key" />
                </label> 
            </div>
            <div className='form-outline mb-4'>
                <label htmlFor='branchCode'>
                    Sucursal
                    <input id="branchCode" onChange = {(e) => setBranchCode(e.target.value)} value={branchCode} placeholder="Codigo Sucursal" />
                </label>  
            </div>
            <div className='form-outline mb-4'>
                <label htmlFor='emailAdmin'>
                    Correo de Administrador WR
                    <input id="emailAdmin" onChange = {(e) => setEmailAdmin(e.target.value)} value={emailAdmin} placeholder="Email Admnistrador" />
                </label>  
            </div>
            
            <button className='btn btn-primary btn-block mb-4'>Save</button>
            </form>
        </div>
     );
}

export default Dashboard;