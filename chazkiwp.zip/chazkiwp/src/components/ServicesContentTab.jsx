import React, { useState, Component } from 'react'
import apiFetch from '@wordpress/api-fetch';

import PropTypes from 'prop-types';

class ServicesContentTab extends Component {
    static propTypes = {      
      branchCode: PropTypes.string.isRequired,      
    };

    render() {
      return (
        <div>
          
        </div>
      );
    }

}
export default ServicesContentTab;